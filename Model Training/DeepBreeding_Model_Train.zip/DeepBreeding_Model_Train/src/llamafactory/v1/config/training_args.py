# Copyright 2025 the LlamaFactory team.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import os
from dataclasses import dataclass, field
from typing import Literal
from uuid import uuid4

from .arg_utils import BatchingStrategy, PluginConfig, get_plugin_config


@dataclass
class TrainingArguments:
    output_dir: str = field(
        default=os.path.join("outputs", str(uuid4().hex)),
        metadata={"help": "Path to the output directory."},
    )
    micro_batch_size: int = field(
        default=1,
        metadata={"help": "Micro batch size for training."},
    )
    global_batch_size: int | None = field(
        default=None,
        metadata={"help": "Global batch size for training, default to DP size * micro batch size."},
    )
    cutoff_len: int = field(
        default=2048,
        metadata={"help": "Maximum sequence length for training."},
    )
    learning_rate: float = field(
        default=1e-4,
        metadata={"help": "Learning rate for training."},
    )
    num_train_epochs: int = field(
        default=3,
        metadata={"help": "Number of training epochs."},
    )
    max_steps: int | None = field(
        default=None,
        metadata={"help": "Maximum number of training steps. If set, overrides num_train_epochs."},
    )
    max_grad_norm: float = field(
        default=1.0,
        metadata={"help": "Maximum gradient norm for training."},
    )
    bf16: bool = field(
        default=True,
        metadata={"help": "Use bf16 for training."},
    )
    batching_strategy: BatchingStrategy = field(
        default=BatchingStrategy.NORMAL,
        metadata={"help": "Batching strategy for training."},
    )
    batching_workers: int = field(
        default=16,
        metadata={"help": "Number of workers for batching."},
    )
    enable_activation_checkpointing: bool = field(
        default=True,
        metadata={"help": "Enable activation checkpointing for training."},
    )
    dist_config: PluginConfig | None = field(
        default=None,
        metadata={"help": "Distribution configuration for training."},
    )
    optim_config: PluginConfig | None = field(
        default=None,
        metadata={"help": "Optimizer configuration for training."},
    )
    lr_scheduler_config: PluginConfig | None = field(
        default=None,
        metadata={"help": "Learning rate scheduler configuration for training."},
    )
    seed: int = field(
        default=42,
        metadata={"help": "Random seed that will be set at the beginning of training."},
    )
    full_determinism: bool = field(
        default=False,
        metadata={"help": "Enable full deterministic mode for reproducible distributed training."},
    )
    resume_from_checkpoint: str | None = field(
        default=None,
        metadata={"help": "Path to a checkpoint directory to resume training from, or 'auto' to find the latest."},
    )
    save_steps: int | None = field(
        default=None,
        metadata={"help": "Save a training checkpoint every N global steps."},
    )
    save_epochs: float | None = field(
        default=None,
        metadata={"help": "Save a training checkpoint every N epochs."},
    )
    save_ckpt_as_hf: bool = field(
        default=False,
        metadata={
            "help": "Save intermediate checkpoints in HuggingFace format instead of distributed format. Warning: doubles memory usage."
        },
    )
    save_total_limit: int | None = field(
        default=None,
        metadata={"help": "Maximum number of checkpoints to keep. Oldest checkpoints are deleted."},
    )
    logging_steps: int = field(
        default=1,
        metadata={"help": "Log metrics every N optimizer steps."},
    )
    pref_loss: Literal["sigmoid", "orpo", "simpo"] = field(
        default="sigmoid",
        metadata={"help": "The type of DPO loss to use."},
    )
    pref_beta: float = field(
        default=0.1,
        metadata={"help": "The beta parameter in the preference loss."},
    )
    pref_ftx: float = field(
        default=0.0,
        metadata={"help": "The supervised fine-tuning loss coefficient in DPO training."},
    )
    simpo_gamma: float = field(
        default=0.5,
        metadata={"help": "The target reward margin term in SimPO loss."},
    )
    dpo_label_smoothing: float = field(
        default=0.0,
        metadata={"help": "The robust DPO label smoothing parameter in cDPO that should be between 0 and 0.5."},
    )
    ld_alpha: float | None = field(
        default=None,
        metadata={"help": "Alpha parameter from LD-DPO, controls weighting of verbose token log-probabilities."},
    )

    def __post_init__(self) -> None:
        self.dist_config = get_plugin_config(self.dist_config)
        self.optim_config = get_plugin_config(self.optim_config)
        self.lr_scheduler_config = get_plugin_config(self.lr_scheduler_config)

        if str(self.batching_strategy) == str(BatchingStrategy.DYNAMIC_BATCHING):
            if self.max_steps is None or self.max_steps <= 0:
                raise ValueError("`dynamic_batching` requires `max_steps` because it is step-driven.")
            if self.save_epochs is not None:
                raise ValueError("`save_epochs` is not supported with `dynamic_batching`; use `save_steps` instead.")
